from lrc_kit.line import LyricLine
from lrc_kit.lrc import LRC
from lrc_kit.parser import parse_lyrics
from lrc_kit.providers import *