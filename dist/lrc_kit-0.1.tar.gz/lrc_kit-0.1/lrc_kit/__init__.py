from lyrics.line import LyricLine
from lyrics.lrc import LRC
from lyrics.parser import parse_lyrics
from lyrics.providers import *